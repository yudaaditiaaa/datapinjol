<div class="container">
    <form action="" method="post">
        <legend>Ubah Data Peminjam</legend>
        <div class="mb-3">
            <input type="hidden" name="id" value="<?= $peminjam['id']; ?>">
            <label for="peminjam" class="form-label">Nama Peminjam</label>
            <input type="text" class="form-control" id="peminjam" name="peminjam" value="<?= $V['peminjam']; ?>" style="width : 300px;">
            <div class="form-text text-danger"><?= form_error('peminjam'); ?></div>
        </div>
        <input type="submit" name="ubah" value="ubah" class="btn btn-primary"></input>
    </form>
</div>
<style>
    body {
        background-color: grey;
    }
    </style>
