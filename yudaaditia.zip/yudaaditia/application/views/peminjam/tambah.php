<div class="container">
    <form action="" method="post">
        <legend>Tambah Data Peminjam</legend>
        <div class="mb-3">
            <label for="peminjam" class="form-label">Nama Peminjam</label>
            <input type="text" class="form-control" id="peminjam" name="peminjam" style="width : 300px;">
            <div class="form-text text-danger"><?= form_error('peminjam'); ?></div>
        </div>
        <input type="submit" value="submit" class="btn btn-primary"></input>
    </form>
</div>
<style>
    body {
        background-color: grey;
    }
    </style>
